
var apn = require('apn');
var fs = require('fs');

//var data = fs.readFileSync('kaola_apn.p12');
var data = fs.readFileSync('aps_out.p12');
//console.log(data);
//console.log(typeof data);


var options = { "production": true,"passphrase":'12345',"pfxData": data };

var apnConnection = new apn.Connection(options);

//var token = "15f4ee446c9505cfd3cc2bfa1927b91dd8064b2331e3dd9daf212d842a0f0058"  eduiphone
//var token = "e245cc2121c20d624d9362b5046e6f841b97d56fd2d5c969704db4b735316c32"
//var token = "e73a3b88e33f38768f97ad82e742ea37bfff5b5911ded32ac4300bef03ab35f7"
//var token = "3179763f78ae3499f9114ac8ef36d8328a2b5d21bc74d199eaa14c3c2ba51b2e";
//var token = '482474b4fa14573cf2603293418dcb7f5429a233231548ca8572a1c479d1d0cf';
//var token = 'ce1176e8a93f602a96b91520068def9d98e0551ca993558fc8f958a9295092ac';
//var token = 'aee9a2268aeecf7483e072a018393d34d45a5079084f33f8ec480f5f8ede8e72';
//var token = '3d9ecb1016c78091d69976cfe2ed49b4ad762a0ff22ccdd3d26db57c3a131385';
var token = '1ebfd1716016b4e34da9d58ad071d99a0d74e36631f66c561c815bcc50ed605f';
var myDevice = new apn.Device(token);

var note = new apn.Notification();

note.expiry = Math.floor(Date.now() / 1000) + 3600; // Expires 1 hour from now.
note.badge = 3;
note.sound = "ping.aiff";
note.alert = "\uD83D\uDCE7 \u2709  \uD83D\uDE05 You have a new message:smile ";
note.payload = {'messageFrom': 'Caroline','content': '1222222222222222222 Push-server - a scalable, distributed platform for push messaging servicePush-server is a scalable, distributed platform which can help you push message to terminals,such as android, iOS and web. It is writen in NodeJS and based on pomelo. Pomelo is a fast, scalable game server framework for node.js, also it is suitable for realtime web applications.## Features* Support offline messages* Add server dynamically* Higher success rate* Multi-platform support## DocumentsAll of the documents are listed in wiki [push-server] (http://doc.hz.netease.com/pages/viewpage.action?pageId=32089072)## License(The MIT License)Copyright (c) 2013 NetEase, Inc. and other contributors     Permission is hereby granted, ree of charge, to any person obtaining    a copy of this software and associated documentation files (the Software), to deal in the     Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:      The above copyright notice and this permission notice shall be  included in all copies or substantial portions of the Software.E SOFTWARE IS PROVIDED AS IS, WITHOUT WARRANTY OF ANY KIND,    EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY    CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,    TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE  SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.*  Push-server - a scalable, distributed platform for push messaging servicePush-server is a scalable, distributed platform which can help you push message to terminals,such as android, iOS and we'};
//note.encoding = 'ucs2';
//console.log(note.length(),note.compiled.length,'---',note);
note.trim();
console.log(note.length(),note.compiled.length,'---',note);
apnConnection.on('connected',function(){console.log('connectted');});
apnConnection.on('disconnected',function(){console.log('disconnected');});
apnConnection.on('transmissionError', function(errCode, notification, recipient) {console.log(errCode +'  :' +  recipient)});
apnConnection.pushNotification(note, myDevice);

