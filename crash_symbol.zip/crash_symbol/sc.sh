crash_log_file=$1
dSYM_dir=$2
output_file=$3 

print_usage() {
	echo 'invalid args: 1.crash log file; 2.dSYM; 3.output(optinal);'
}

if test -z $crash_log_file; then
	print_usage
	exit 1
fi

if test -z $dSYM_dir; then
	print_usage
	exit 2
fi

if test -z $output_file; then
	output_file='out.txt'
fi


#export DEVELOPER_DIR="/Applications/Xcode.app/Contents/Developer"
export DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer

./symbolicatecrash -v $crash_log_file $dSYM_dir 1>$output_file 2>&1
